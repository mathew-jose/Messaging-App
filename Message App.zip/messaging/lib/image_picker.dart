import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ImagePick extends StatefulWidget {
  final void Function(File image) imagees;
  ImagePick(this.imagees);
  @override
  _ImagePickState createState() => _ImagePickState();
}

class _ImagePickState extends State<ImagePick> {
  File imagepicked;
  void pickimage()async{
  final image= await ImagePicker.pickImage(source: ImageSource.camera,imageQuality: 65,maxWidth:150, );
  setState(() {
    imagepicked=image;
  widget.imagees(imagepicked);
  });

  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        CircleAvatar(
          radius: 40,
          backgroundImage: imagepicked !=null ?  FileImage(imagepicked): null,
          backgroundColor: Colors.grey,
        ),
        FlatButton.icon(
            onPressed:  pickimage,
            icon: Icon(Icons.add_a_photo),
            label: Text("Add An Image")),
      ],
    );
  }
}
