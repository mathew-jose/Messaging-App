import 'package:flutter/material.dart';

class Bubble extends StatelessWidget {
  final String message;
  final String username;
  final bool me;
  final Key key;
  final String url;
  Bubble(this.message,this.username,this.me,this.url,{this.key});
  @override
  Widget build(BuildContext context) {
    return Stack(
          children:<Widget>[ 
        Row(
        mainAxisAlignment: me? MainAxisAlignment.end : MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10),
topRight: Radius.circular(10),
bottomLeft: me? Radius.circular(10): Radius.circular(0),
bottomRight: me? Radius.circular(0): Radius.circular(10),

            ),
            color:me ? Colors.red : Colors.green
            ),
            padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
            margin: EdgeInsets.symmetric(vertical:13,horizontal:8),
            child: Column(
              crossAxisAlignment:!me? CrossAxisAlignment.start:CrossAxisAlignment.end,
              children: <Widget>[
               

                    Container(
                      padding: EdgeInsets.symmetric(vertical:5),
                      child: Text(me ?username+"     ":"     "+username,style: TextStyle(fontWeight: FontWeight.bold,))),
  
                Text(message,style: TextStyle(color:Colors.white),textAlign: me ? TextAlign.end: TextAlign.start,)

              
        ],))]

      ),
              Positioned(
                top:-5,
                right:me ? 0:null,
                left: me ? null:0, 
                child: CircleAvatar(backgroundImage: NetworkImage(url),
                radius:   17,
            ),
                
                )

 ],
 overflow: Overflow.visible,   );
  }
}