import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import './auth_form.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final auth = FirebaseAuth.instance;
  var loading = false;
  void submit(String email, String username, String password, bool login,
      File image, BuildContext ctx) async {
    AuthResult authresult;
    try {
      setState(() {
        loading = true;
      });
      if (login) {
        authresult = await auth.signInWithEmailAndPassword(
            email: email, password: password);
      } else {
        authresult = await auth.createUserWithEmailAndPassword(
            email: email, password: password);
        final store = FirebaseStorage.instance
            .ref()
            .child('user_images')
            .child(authresult.user.uid + '.jpg');

        await store.putFile(image).onComplete;
        final url = await store.getDownloadURL();
        await Firestore.instance
            .collection('users')
            .document(authresult.user.uid)
            .setData({
          'username': username,
          'email': email,
          'image_url': url,
        });
      }
    } on PlatformException catch (error) {
      var message = ' An error occured, please check credentials';
      if (error.message != null) {
        message = error.message;
      }

      Scaffold.of(ctx).showSnackBar(SnackBar(
        content: Text(message),
        backgroundColor: Colors.black,
      ));
      setState(() {
        loading = false;
      });
    } catch (err) {
      print(err);
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink,
      body: SingleChildScrollView(
              child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Container(height:200),
            Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.black,
                  border: Border.all(width: 8, color: Colors.blue)),
              height: 130,
              width: double.infinity,
              //  color: Colors.black,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  "\nChat Now ",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            AuthForm(submit, loading),
          ],
        ),
      ),
    );
  }
}
