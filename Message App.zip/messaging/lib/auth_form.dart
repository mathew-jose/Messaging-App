import "package:flutter/material.dart";
import 'package:messaging/image_picker.dart';
import 'dart:io';

class AuthForm extends StatefulWidget {
  final bool loading;
  final void Function(String email, String username, String password,
      bool login, File image, BuildContext ctx) submit;
  AuthForm(this.submit, this.loading);
  @override
  _AuthFormState createState() => _AuthFormState();
}

class _AuthFormState extends State<AuthForm> {
  File image;
  final formkey = GlobalKey<FormState>();
  bool islogin = true;
  String email = "";
  String username = "";
  String password = "";

  void pick(File pickim) {
    image = pickim;
  }

  void trysubmit() {
    final valid = formkey.currentState.validate();
    FocusScope.of(context).unfocus();
    if (!islogin&&image == null) {
      Scaffold.of(context).showSnackBar(SnackBar(
        content: Text(
          "No Image Was Added",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
      ));
      return ;
    }
    if (valid) {
      formkey.currentState.save();
      widget.submit(email.trim(), username.trim(), password.trim(), islogin,
          image, context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Card(
              elevation: 20,
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Form(
                    key: formkey,
                    child: Column(
                      children: <Widget>[
                        if (!islogin) ImagePick(pick),
                        TextFormField(
                          key: ValueKey('email'),
                          autocorrect: false,
                          textCapitalization: TextCapitalization.none,
                          enableSuggestions: false,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(labelText: "Email"),
                          validator: (value) {
                            if (value.isEmpty || !value.contains('@')) {
                              return ' Enter A Vaid Email';
                            } else
                              return null;
                          },
                          onSaved: (value) {
                            email = value;
                          },
                        ),
                        if (!islogin)
                          TextFormField(
                            key: ValueKey('username'),
                            autocorrect: true,
                          textCapitalization: TextCapitalization.words,
                          enableSuggestions: false,
                          
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(labelText: "UserName"),
                            validator: (value) {
                              if (value.isEmpty || value.length < 5) {
                                return 'Username Must Be Atleast 5 Characters';
                              } else
                                return null;
                            },
                            onSaved: (value) {
                              username = value;
                            },
                          ),
                        TextFormField(
                          key: ValueKey('password'),
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(labelText: "Password"),
                          obscureText: true,
                          validator: (value) {
                            if (value.isEmpty || value.length < 8) {
                              return 'Password Must Be Atleast 8 Characters';
                            } else
                              return null;
                          },
                          onSaved: (value) {
                            password = value;
                          },
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        if (widget.loading)
                          CircularProgressIndicator()
                        else
                          RaisedButton(
                            child: Text(
                              islogin ? "Login" : "SignUp",
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: trysubmit,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            color: Colors.black,
                          ),
                        FlatButton(
                          child: Text(islogin
                              ? "Create New Account"
                              : " I Already Have an Account"),
                          onPressed: () {
                            setState(() {
                              islogin = !islogin;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              )),
        ),
      ),
    );
  }
}
